<?php include_once('partials/layout.php'); ?>


<?php function get_page_content() { ?>
<!-- HTML Content Here -->
    <div id="test">
        <div class="d-flex flex-row d-md-block">
            <div class="box green">
            </div>
            <div class="box blue"></div>
        </div>
    </div>
            
<?php }; ?>	