<header>
    <div id="logo-title">
        <h1><a href="index.php">Michelle Suniga</a></h1>
        <p>Full Stack Web Developer</p>
    </div>
    <nav class="d-none">
        <div id="my-nav">
            <ul class="d-flex">
                <li><a class="nav-hover my-nav-item" href="#">FAQs</a></li>
                <li><a class="nav-hover my-nav-item" href="#">Contacts</a></li>
            </ul>
        </div>
    </nav>
</header>