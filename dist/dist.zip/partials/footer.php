    <footer class="d-flex justify-content-between "> 
        <div class="align-self-center">
            <p>Michelle Suniga &copy; 2019</p>
        </div>
        <div class="align-self-center">
            <a href="mailto:suniga.mrs@gmail.com">suniga.mrs@gmail.com</a>
        </div>
    </footer>

    <!-- jQuery library -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom JS -->
    <script src="assets/js/main.js"></script>

</body>
</html>