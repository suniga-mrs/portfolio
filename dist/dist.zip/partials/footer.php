    <footer class="d-flex justify-content-between "> 
        <div class="align-self-center">
            <a href="https://twitter.com/michiesuniga" target="_blank"><img src="assets/images/sm-twitter.svg" alt="Twitter"></a>
            <a href="https://www.behance.net/msuniga"  target="_blank"><img src="assets/images/sm-behance.svg" alt="Behance"></a>
            <a href="https://github.com/suniga-mrs" target="_blank"><img src="assets/images/sm-github.svg" alt="Github"></a>
        </div>
        <!-- <div class="align-self-center text-center">
            <p>Michelle Suniga &copy; 2019</p>
        </div> -->
        <div class="align-self-center">
            <a href="mailto:suniga.mrs@gmail.com">suniga.mrs@gmail.com</a>
        </div>
    </footer>

    <!-- jQuery library -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- AOS Library -->
    <script src="vendor/aos/aos.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/main.js"></script>

</body>
</html>