<?php include_once('partials/layout.php'); ?>


<?php function get_page_content() { ?>
<!-- HTML Content Here -->
<?php }; ?>	